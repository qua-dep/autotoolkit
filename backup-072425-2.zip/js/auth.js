document.addEventListener('DOMContentLoaded', () => {
    const userMenuButton = document.getElementById('user-menu-button');
    const userMenuDropdown = document.getElementById('user-menu-dropdown');
    const user = JSON.parse(localStorage.getItem('user'));

    function setupDropdown() {
        if (user) {
            // User is logged in
            userMenuDropdown.innerHTML = `
                <a href="#" id="logout-button" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Log Out</a>
            `;
            document.getElementById('logout-button').addEventListener('click', (e) => {
                e.preventDefault();
                localStorage.removeItem('user');
                window.location.href = '/';
            });
        } else {
            // User is logged out
            userMenuDropdown.innerHTML = `
                <a href="/signup.html" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Sign Up</a>
                <a href="/login.html" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Log In</a>
            `;
        }
    }

    if (userMenuButton && userMenuDropdown) {
        setupDropdown();

        userMenuButton.addEventListener('click', () => {
            userMenuDropdown.classList.toggle('hidden');
        });

        // Close dropdown if clicking outside
        document.addEventListener('click', (e) => {
            if (!userMenuButton.contains(e.target) && !userMenuDropdown.contains(e.target)) {
                userMenuDropdown.classList.add('hidden');
            }
        });
    }
});
